<?php $__env->startSection('title'); ?>
    Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="cmt-page-title-row cmt-bgimage-yes cmt-bg cmt-bgcolor-darkgrey">
        <div class="cmt-row-wrapper-bg-layer cmt-bg-layer"></div>
        <div class="cmt-page-title-row-inner">
            <div class="container">
                <div class="row align-items-center text-center">
                    <div class="col-lg-12">
                        <div class="page-title-heading">
                            <h2 class="title">Products</h2>
                        </div>
                        <div class="breadcrumb-wrapper">
                            <span><a href="<?php echo e(route('index')); ?>">Home</a> / </span>
                            <span>Products</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="site-main">
        <section class="cmt-row grid-section clearfix">
            <div class="container">
                <div class="row row-equal-height cmt-boxes-spacing-25px">
                    <?php $__empty_1 = true; $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="cmt-box-col-wrapper col-lg-4">
                            <div class="featured-imagebox featured-imagebox-post style1">
                                <div class="cmt-post-thumbnail featured-thumbnail">
                                    <img width="770" height="530" class="img-fluid" src="<?php echo e(asset('images/products/' . $productCategory->image)); ?>" alt="">
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h3><a href="<?php echo e(route('product-categories.show', $productCategory)); ?>"><?php echo e($productCategory->title); ?></a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center">No products found!</div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dh_e75x9n/aerotek.lk/resources/views/app/products/index.blade.php ENDPATH**/ ?>