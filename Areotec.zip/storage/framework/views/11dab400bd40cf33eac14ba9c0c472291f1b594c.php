<a id="totop" href="#top">
    <i class="fa fa-angle-up"></i>
</a>
<?php /**PATH /home/enindu/Work/HTML/Phyxle/Pathum/aerotek/resources/views/components/includes/top.blade.php ENDPATH**/ ?>