<a id="totop" href="#top">
    <i class="fa fa-angle-up"></i>
</a>
<?php /**PATH /home/dh_e75x9n/aerotek.lk/resources/views/components/includes/top.blade.php ENDPATH**/ ?>