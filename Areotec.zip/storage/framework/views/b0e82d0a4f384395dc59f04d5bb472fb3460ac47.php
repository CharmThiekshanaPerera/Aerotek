<div id="preloader" class="blobs">
    <div class="loader-blob-center"></div>
    <div class="loader-blob"></div>
    <div class="loader-blob"></div>
    <div class="loader-blob"></div>
    <div class="loader-blob"></div>
    <div class="loader-blob"></div>
    <div class="loader-blob"></div>
</div>
<?php /**PATH /home2/ucfwrite/public_html/website_581aa544/resources/views/components/includes/preloader.blade.php ENDPATH**/ ?>