<?php $__env->startSection('title'); ?>
    <?php echo e($productCategory->title); ?> | Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="cmt-page-title-row cmt-bgimage-yes cmt-bg cmt-bgcolor-darkgrey">
        <div class="cmt-row-wrapper-bg-layer cmt-bg-layer"></div>
        <div class="cmt-page-title-row-inner">
            <div class="container">
                <div class="row align-items-center text-center">
                    <div class="col-lg-12">
                        <div class="page-title-heading">
                            <h2 class="title"><?php echo e($productCategory->title); ?></h2>
                        </div>
                        <div class="breadcrumb-wrapper">
                            <span><a href="<?php echo e(route('index')); ?>">Home</a> / </span>
                            <span><a href="<?php echo e(route('products.index')); ?>">Products</a> / </span>
                            <span><?php echo e($productCategory->title); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="site-main">
        <section class="pt-70 tab-section clearfix pr-10 pl-10">
            <div class="container">
                <div class="row">
                    <div class="res-991-pr-0 pr-40">
                        <div class="section-title with-desc">
                            <div class="title-header">
                                <h2 class="title"><?php echo e($productCategory->title); ?></h2>
                            </div>
                            <div class="title-desc">
                                <p><?php echo e($productCategory->content); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="pb-70 grid-section clearfix">
            <div class="container">
                <div class="row row-equal-height cmt-boxes-spacing-25px">
                    <?php $__empty_1 = true; $__currentLoopData = $productCategory->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="cmt-box-col-wrapper col-lg-4">
                            <div class="featured-imagebox featured-imagebox-post style1">
                                <div class="cmt-post-thumbnail featured-thumbnail">
                                    <img width="770" height="530" class="img-fluid" src="<?php echo e(asset('images/products/' . $product->image)); ?>" alt="">
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h3><a href="#"><?php echo e($product->title); ?></a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center">No products found!</div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dh_e75x9n/aerotek.lk/resources/views/app/product-categories/show.blade.php ENDPATH**/ ?>