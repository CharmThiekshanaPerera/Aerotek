<a id="totop" href="#top">
    <i class="fa fa-angle-up"></i>
</a>
<?php /**PATH /home2/ucfwrite/public_html/website_581aa544/resources/views/components/includes/top.blade.php ENDPATH**/ ?>