<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH /home/dh_e75x9n/aerotek.lk/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/table.blade.php ENDPATH**/ ?>