<?php $__env->startSection('title'); ?>
    <?php echo e($projectCategory->title); ?> | Projects
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="cmt-page-title-row cmt-bgimage-yes cmt-bg cmt-bgcolor-darkgrey">
        <div class="cmt-row-wrapper-bg-layer cmt-bg-layer"></div>
        <div class="cmt-page-title-row-inner">
            <div class="container">
                <div class="row align-items-center text-center">
                    <div class="col-lg-12">
                        <div class="page-title-heading">
                            <h2 class="title"><?php echo e($projectCategory->title); ?></h2>
                        </div>
                        <div class="breadcrumb-wrapper">
                            <span><a href="<?php echo e(route('index')); ?>">Home</a> / </span>
                            <span><a href="<?php echo e(route('projects.index')); ?>">Projects</a> / </span>
                            <span> <?php echo e($projectCategory->title); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="site-main">
        <section class="cmt-row project-single-section clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="cmt-pf-single-content-wrapper-innerbox cmt-pf-view-left-image">
                            <div class="cmt-pf-single-related-wrapper mb_15">
                                <div class="row">
                                    <?php $__empty_1 = true; $__currentLoopData = $projectCategory->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="cmt-box-col-wrapper col-lg-4 col-md-4 col-sm-6">
                                            <div class="featured-imagebox featured-imagebox-portfolio style1">
                                                <div class="cmt-box-view-overlay">
                                                    <div class="featured-thumbnail">
                                                        <img width="600" height="750" class="img-fluid" src="<?php echo e(asset('images/projects/' . $project->image)); ?>" alt="">
                                                    </div>
                                                    <div class="cmt-media-link">
                                                        <a class="cmt_prettyphoto cmt_image" data-gal="prettyPhoto[gallery1]" href="<?php echo e(asset('images/projects/' . $project->image)); ?>" data-rel="prettyPhoto" tabindex="0">
                                                            <i class="ti ti-search"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="col-12 text-center">No projects found!</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dh_e75x9n/aerotek.lk/resources/views/app/project-categories/show.blade.php ENDPATH**/ ?>