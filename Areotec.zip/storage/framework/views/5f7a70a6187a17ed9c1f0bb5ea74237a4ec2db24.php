<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="Brandix">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/brandix.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="Camso Loadstar">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/camso-loadstar.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="CBL">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/cbl.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="Cargills">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/cargills.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="Elephant House">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/elephant-house.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="Expack">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/expack.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="Freelan">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/freelan.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="Hayleys">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/hayleys.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="Hirdaramani">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/hirdaramani.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="MAS">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/mas.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="MIDAS">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/midas.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12">
    <div class="client-box">
        <div class="cmt-client-logo-tooltip" data-tooltip="Shangrila">
            <div class="client-thumbnail">
                <img class="img-fluid" src="<?php echo e(asset('images/clients/shangrila.png')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home2/ucfwrite/public_html/website_581aa544/resources/views/components/includes/clients.blade.php ENDPATH**/ ?>