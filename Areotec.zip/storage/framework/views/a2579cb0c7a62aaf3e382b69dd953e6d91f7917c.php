<?php echo e($slot); ?>

<?php /**PATH /home/dh_e75x9n/aerotek.lk/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>